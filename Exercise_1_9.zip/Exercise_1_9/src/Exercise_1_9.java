/*
Author: Kaden Payne
Date: 4/7/2020
 */

/**
 *
 * @author kjpay
 */
public class Exercise_1_9 {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        System.out.println(2 * (7.9 + 4.5));
        System.out.println(7.9 * 4.5) ;
    }
}
    
