/*
Author: Kaden Payne
Date: 4/7/2020

Solves (9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5)
 */

/**
 *
 * @author kjpay
 */
public class Exercise_1_5 {
 
    /**
     *
     * @param args
     */
    public static void main(String[] args) { 
        System.out.println((9.5 * 4.5 - 2.5 * 3)/ (45.5 - 3.5)) ;
    }
}